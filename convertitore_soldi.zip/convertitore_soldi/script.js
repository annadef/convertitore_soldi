let numero1 = document.getElementById('numero1');
let bottone = document.getElementById('converti');
let risultato = document.getElementById('risultato');
let valuta1 = document.getElementById('valuta1');
let valuta2 = document.getElementById('valuta2');
let reset = document.getElementById('reset');
let bandiera1 = document.getElementById('immagine1');
let bandiera2 = document.getElementById('immagine2');

let tassiConversione = [];
tassiConversione[0]=[];
tassiConversione[1]=[null, 1, 1.13, 0.83, 128.80, 7.13];
tassiConversione[2]=[null, 0.89, 1, 0.74, 114.19, 6.32];
tassiConversione[3]=[null, 1.20, 1.35, 1, 154.10, 8.54];
tassiConversione[4]=[null, 0.0078, 0.0088, 0.0065, 1, 0.055];
tassiConversione[5]=[null, 0.14, 0.16, 0.12, 18.05, 1];
/* console.log(tassiConversione[1][2]); */

let img = ['europe-flag-medium.jpg',
           'united-states-of-america-flag-medium.jpg',
           'united-kingdom-flag-medium.jpg',
           'japan-flag-medium.jpg',
           'china-flag-medium.jpg'
        ];
window.addEventListener('load', init);

function init(){
    numero1.value = '';
    risultato.value = '';
    bottone.addEventListener('click', controlla);
    reset.addEventListener('click', resetta);
}

function controlla (){
    risultato.innerHTML = '';
    bandiera1.innerHTML='';
    bandiera2.innerHTML='';
    let indice1 = valuta1.selectedIndex;
    let indice2 = valuta2.selectedIndex;
    esegui(indice1, indice2);
}

function esegui(valutaPartenza, valutaArrivo){
    let conversione;
    let moneta1;
    let moneta2;

    if(numero1.value == ''){
        risultato.innerHTML = 'Inserisci un importo valido';
        return;
    }
    switch(valutaPartenza){
        case 0:
            risultato.innerHTML= 'Inserisci una valuta valida';
            return;
        case 1:
            moneta1 = 'Euro';
            bandiera1.innerHTML += `<img src="img/${img[0]}" class="img-fluid">`;
            break;
        case 2:
            moneta1 = 'Dollari';
            bandiera1.innerHTML += `<img src="img/${img[1]}" class="img-fluid">`;
            break;
        case 3:
            moneta1 = 'Pound';
            bandiera1.innerHTML += `<img src="img/${img[2]}" class="img-fluid">`;
            break;
        case 4:
            moneta1 = 'Yen';
            bandiera1.innerHTML += `<img src="img/${img[3]}" class="img-fluid">`;
            break;
        case 5:
            moneta1 = 'Yuan';
            bandiera1.innerHTML += `<img src="img/${img[4]}" class="img-fluid">`;
            break;
    }

    switch(valutaArrivo){
        case 0:
            risultato.innerHTML= 'Inserisci una valuta valida';
            return;
        case 1:
            moneta2 = 'Euro';
            bandiera2.innerHTML += `<img src="img/${img[0]}" class="img-fluid">`;
            break;
        case 2:
            moneta2 = 'Dollari';
            bandiera2.innerHTML += `<img src="img/${img[1]}" class="img-fluid">`;
            break;
        case 3:
            moneta2 = 'Pound';
            bandiera2.innerHTML += `<img src="img/${img[2]}" class="img-fluid">`;
            break;
        case 4:
            moneta2 = 'Yen';
            bandiera2.innerHTML += `<img src="img/${img[3]}" class="img-fluid">`;
            break;
        case 5:
            moneta2 = 'Yuan';
            bandiera2.innerHTML += `<img src="img/${img[4]}" class="img-fluid">`;
            break;
    }
    
    conversione = (Number(numero1.value) * tassiConversione[valutaPartenza][valutaArrivo]);
    scrivi(moneta1, moneta2, conversione);
}

function scrivi(stringa1, stringa2, esito) {

    
    risultato.innerHTML = numero1.value + ' ' + stringa1 + ' corrispondono a ' + esito.toFixed(2) + ' ' + stringa2;
    numero1.value = '';
} 

function resetta(){
    numero1.value = '';
    risultato.innerHTML='';
    valuta1.selectedIndex = 0;
    valuta2.selectedIndex = 0;
    bandiera1.innerHTML='';
    bandiera2.innerHTML='';
}